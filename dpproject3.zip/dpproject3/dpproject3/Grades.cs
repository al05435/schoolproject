﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace dpproject3
{
    public partial class Grades : UserControl
    {
        public Grades()
        {
            InitializeComponent();
        }

        private void Grades_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = GetGrades();

        }
        private DataTable GetGrades()
        {
            DataTable dtSchedule = new DataTable();
            string constring = "Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("select CourseName, ObtainedMarks, MaxMarks, [Percentage] from grade G inner join Course C on G.CourseID = C.CourseID where studentID = '" + Form1.SetValueForText1 + "'"
, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    dtSchedule.Load(reader);
                }
            }

            return dtSchedule;

        }
    }
}
