﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace dpproject3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            panel1.Height = button6.Height;
            panel1.Top = button6.Top;
            home1.BringToFront();
        }
        public string con = "Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True";
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel1.Height = button6.Height;
            panel1.Top = button6.Top;
            home1.BringToFront();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Height = button1.Height;
            panel1.Top = button1.Top;
            personalinfo1.BringToFront();
            home1.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Height = button2.Height;
            panel1.Top = button2.Top;
            classSchedule1.BringToFront();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Height = button3.Height;
            panel1.Top = button3.Top;
            grades1.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Height = button4.Height;
            panel1.Top = button4.Top;
            fee1.BringToFront();
            home1.BringToFront();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel1.Height = button5.Height;
            panel1.Top = button5.Top;
            enrollment1.BringToFront();
        }
    }
}
