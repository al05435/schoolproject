﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace dpproject3
{
    public partial class Fee : UserControl
    {
        public Fee()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True");

        private void Fee_Load(object sender, EventArgs e)
        {
            checkBox1.Enabled = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True";
            con.Open();
            SqlCommand cmd = new SqlCommand("select [year], [Month], Fee, Discount, Due, Paid from dues D inner join studentinfo SF on D.DueID = SF.DueID where studentID ='" + Form1.SetValueForText1 + "'", con);
            SqlDataReader da = cmd.ExecuteReader();
            while (da.Read())
            {
                textBox1.Text = da.GetValue(0).ToString();
                textBox2.Text = da.GetValue(1).ToString();
                textBox3.Text = da.GetValue(2).ToString();
                textBox4.Text = da.GetValue(3).ToString();
                textBox5.Text = da.GetValue(4).ToString();
                string paid = da.GetValue(5).ToString();
                if (paid == "true")
                {
                    checkBox1.Checked = true;
                }

            }
            con.Close();

        }
    }
}
