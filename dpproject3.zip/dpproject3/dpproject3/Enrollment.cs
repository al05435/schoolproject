﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace dpproject3
{
    public partial class Enrollment : UserControl
    {
        public Enrollment()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Enrollment_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = true;
            
        }
        private DataTable GetDetails()
        {
            DataTable dtSchedule = new DataTable();
            string constring = "Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("select CourseID, CourseName, InstructorName, [Time], days from Enrollment", con)) 
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    dtSchedule.Load(reader);
                }
            }
            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            checkBoxColumn.HeaderText = "";
            checkBoxColumn.Width = 30;
            checkBoxColumn.Name = "checkBoxColumn";
            dataGridView1.Columns.Insert(0, checkBoxColumn);
            return dtSchedule;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True");
            DataTable dt = new DataTable();

            if (comboBox1.Text.Length > 0)
            {

                SqlDataAdapter sda = new SqlDataAdapter("select CourseID, CourseName, InstructorName, [Time], days from Enrollment where CourseID like'" + comboBox1.Text + "%'", con);
                sda.Fill(dt);

            }
            
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = GetDetails();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int inserted = 0;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                bool isSelected = Convert.ToBoolean(row.Cells["checkBoxColumn"].Value);
                if (isSelected)
                {

                    string constring = "Data Source = DESKTOP - RSFTGII; Initial Catalog = school; Integrated Security = True";
                    using (SqlConnection con = new SqlConnection(constring))
                    {
                        using (SqlCommand cmd = new SqlCommand("INSERT INTO Schedulee values(CourseID, [day], [time])", con))
                        {
                            cmd.Parameters.AddWithValue("CourseID", row.Cells["CourseID"].Value);
                            cmd.Parameters.AddWithValue("day", row.Cells["days"].Value);
                            cmd.Parameters.AddWithValue("time", row.Cells["Time"].Value);
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();

                        }
                    }
                    inserted++;
                }
            }

            if (inserted > 0)
            {
                MessageBox.Show(string.Format("{0} records inserted.", inserted), "Message");
            }
        }
    }
}
