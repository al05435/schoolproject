﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace dpproject3
{
    public partial class Personalinfo : UserControl
    {
        public Personalinfo()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True");

        private void Personalinfo_Load(object sender, EventArgs e)
        {
            textBox1.Text = Form1.SetValueForText1;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True";
            con.Open();
            SqlCommand cmd = new SqlCommand("Select FirstName, LastName, PhoneNo, address from studentinfo where studentID = '" + textBox1.Text + "'", con);
            SqlDataReader da = cmd.ExecuteReader();
            while (da.Read())
            {
                textBox2.Text = da.GetValue(0).ToString();
                textBox3.Text = da.GetValue(1).ToString();
                textBox4.Text = da.GetValue(2).ToString();
                textBox5.Text = da.GetValue(3).ToString();
            }
            con.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            String query = "update studentinfo set PhoneNo =  '" + textBox4.Text + "' , address = '" + textBox5.Text + "' where studentID ='" + textBox1.Text + "'";
            SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            SDA.SelectCommand.ExecuteNonQuery();
            MessageBox.Show("Information updated successfully.");
            con.Close();

        }
    }
}
