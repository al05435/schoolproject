﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace dpproject3
{
    public partial class ClassSchedule : UserControl
    {
        public ClassSchedule()
        {
            InitializeComponent();
        }

        
    private DataTable GetSchedule()
        {
            DataTable dtSchedule = new DataTable();
            string constring = "Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("select  CourseName, [day], [time] from Course C Inner join Schedulee S on C.CourseID = S.CourseID where studentID = '" + Form1.SetValueForText1 + "'"
, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    dtSchedule.Load(reader);
                }
            }

            return dtSchedule;

        }
        private void ClassSchedule_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = GetSchedule();
        }
    }
}
