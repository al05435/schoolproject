﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace dpproject3
{
    public partial class Home : UserControl
    {
        public Home()
        {
            InitializeComponent();
        }
    }
}
