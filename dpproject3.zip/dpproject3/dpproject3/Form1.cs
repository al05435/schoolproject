﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace dpproject3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True";
            InitializeComponent();
        }
        public static string SetValueForText1 = "";
        public static string SetValueForText2 = "";

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True");
            con.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=DESKTOP-RSFTGII;Initial Catalog=school;Integrated Security=True";
            con.Open();

            SetValueForText1 = textBox1.Text;
            SetValueForText2 = textBox2.Text;

            SqlCommand cmd = new SqlCommand("select StudentID,Password from studentinfo where StudentID='" + textBox1.Text + "'and convert(varchar, Password)='" + textBox2.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                string ID = textBox1.Text;
                Form2 frm2 = new Form2();
                frm2.Show();

            }
            else
            {
                MessageBox.Show("Invalid Login please check username and password");
            }
            con.Close();


        }
    }
}
    
